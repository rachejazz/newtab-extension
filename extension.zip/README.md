# extension
Custom extension for new Tab, supports firefox and chrome
