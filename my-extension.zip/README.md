# extension
Custom extension for new Tab, supported in Chrome 
